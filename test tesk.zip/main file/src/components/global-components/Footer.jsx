import React from "react";
import { Link } from "react-router-dom";
import { sectionData } from "./../../data/section.json";

const Footer = () => {
  let data = sectionData.footer;
  return (
    <>
      {/* <!-- footer --> */}
      <footer className="footer">
        <div className="footer-top">
          <div className="container">
            <div className="row">
              <div className="col-lg-3 col-md-6">
                {/* <!-- single footer item --> */}
                <div className="single-footer-item">
                  {/* <!-- language select --> */}
                  <div className="language-select">
                    <select
                      className="form-select"
                      aria-label="Default select example"
                    >
                      {data.mainFooter.language.map((item, i) => {
                        return (
                          <option key={i} value={item}>
                            {item}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                  {/* <!-- End of language select --> */}

                  {/* <!-- currency select --> */}
                  <div className="currency-select">
                    <select
                      className="form-select"
                      aria-label="Default select example"
                    >
                      {data.mainFooter.currency.map((item, i) => {
                        return (
                          <option key={i} value={item}>
                            {item}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                  {/* <!-- End of currency select --> */}
                </div>
                {/* <!-- End of single footer item --> */}
              </div>

              <div className="col-lg-3 col-md-6">
                {/* <!-- single footer item --> */}
                <div className="single-footer-item">
                  {/* <!-- footer heading --> */}
                  <div className="footer-heading">
                    <h6>Airbnb</h6>
                  </div>
                  <div className="item-content">
                    <ul>
                      <li>
                        <Link to="#!">About us</Link>
                      </li>
                      <li>
                        <Link to="#!">Careers</Link>
                      </li>
                      <li>
                        <Link to="#">Press</Link>
                      </li>
                      <li>
                        <Link to="#">Policies</Link>
                      </li>
                      <li>
                        <Link to="#">Help</Link>
                      </li>
                      <li>
                        <Link to="#">Diversity & Belonging</Link>
                      </li>
                    </ul>
                  </div>
                  {/* <!-- End of footer heading --> */}
                </div>
                {/* <!-- End of single footer item --> */}
              </div>

              <div className="col-lg-3 col-md-6">
                {/* <!-- single footer item --> */}
                <div className="single-footer-item">
                  {/* <!-- footer heading --> */}
                  <div className="footer-heading">
                    <h6>Discover</h6>
                  </div>
                  <div className="item-content">
                    <ul>
                      <li>
                        <Link to="#">Trust & Safety</Link>
                      </li>
                      <li>
                        <Link to="#">Travel Credit</Link>
                      </li>
                      <li>
                        <Link to="#">Gidt Cards</Link>
                      </li>
                      <li>
                        <Link to="#">Airbnb Citizen</Link>
                      </li>
                      <li>
                        <Link to="#">Business Travel</Link>
                      </li>
                      <li>
                        <Link to="#">Guidebooks</Link>
                      </li>
                    </ul>
                  </div>
                  {/* <!-- End of footer heading --> */}
                </div>
                {/* <!-- End of single footer item --> */}
              </div>

              <div className="col-lg-3 col-md-6">
                {/* <!-- single footer item --> */}
                <div className="single-footer-item">
                  {/* <!-- footer heading --> */}
                  <div className="footer-heading">
                    <h6>Hosting</h6>
                  </div>
                  <div className="item-content">
                    <ul>
                      <li>
                        <Link to="#">Why Host</Link>
                      </li>
                      <li>
                        <Link to="#">Hospitality</Link>
                      </li>
                      <li>
                        <Link to="#">Responsible Hosting</Link>
                      </li>
                      <li>
                        <Link to="#">Community Center</Link>
                      </li>
                    </ul>
                  </div>
                  {/* <!-- End of footer heading --> */}
                </div>
                {/* <!-- End of single footer item --> */}
              </div>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <div className="container">
            <div className="row justify-content-between">
              <div className="col-md-6">
                <p>RareMark, Inc</p>
              </div>
              <div className="col-md-6">
                <div className="footer-link">
                  <div className="tarms-link">
                    <ul>
                      <li>
                        <Link to="#">Terms</Link>
                      </li>
                      <li>
                        <Link to="#">Privacy</Link>
                      </li>
                      <li>
                        <Link to="#">Site Map</Link>
                      </li>
                    </ul>
                  </div>
                  <div className="socile-links">
                    <ul>
                      <li>
                        <Link to="#">
                          <i className="fa fa-facebook"></i>
                        </Link>
                      </li>
                      <li>
                        <Link to="#">
                          <i className="fa fa-twitter"></i>
                        </Link>
                      </li>
                      <li>
                        <Link to="#">
                          <i className="fa fa-linkedin"></i>
                        </Link>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
      {/* <!-- footer --> */}
    </>
  );
};
export default Footer;
