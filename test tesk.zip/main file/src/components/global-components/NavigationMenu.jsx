import React, { useState } from "react";
import { Link } from "react-router-dom";

const NavigationMenu = (props) => {
  const [searchInpValue, setSearchInpValue] = useState("");
  const [offcanvasOpen, setOffcanvasOpen] = useState(false);
  return (
    <>
      {/* <!-- Header --> */}
      <header>
        {/* <!-- header top --> */}
        <div className="header-top">
          <div className="container-fluid">
            <div className="row align-items-center">
              <div className="col-lg-6">
                <div className="header-top-meta">
                  <ul className="meta-list">
                    <li>
                      <div className="meta-search">
                        <i className="fa fa-search"></i>
                        <input
                          type="search"
                          placeholder="aneywhere"
                          value={searchInpValue}
                          onChange={(e) => {
                            setSearchInpValue(e.target.value);
                          }}
                        />
                      </div>
                    </li>
                    <li>
                      <div className="meta-position">
                        <i className="fa fa-calendar"></i>
                        <select
                          className="form-select"
                          aria-label="Default select example"
                        >
                          <option value="def">Aneytime</option>
                          <option value="1">Castel House</option>
                          <option value="2">Nowabi House</option>
                          <option value="3">Castal House</option>
                        </select>
                      </div>
                    </li>
                    <li>
                      <div className="meta-guest-count">
                        <i className="fa fa-user"></i>
                        <select
                          className="form-select"
                          aria-label="Default select example"
                        >
                          <option value="def">1 Guest</option>
                          <option value="1">2 Guest</option>
                          <option value="2">3 Guest</option>
                          <option value="3">4 Guest</option>
                        </select>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-lg-6">
                <nav className="top-navigarion">
                  <ul>
                    <li>
                      <span>
                        <i className="fa fa-cloud"></i>
                      </span>
                      <Link to="#">Become a Host</Link>
                    </li>
                    <li>
                      <span>
                        <i className="fa fa-info-circle"></i>
                      </span>
                      <Link to="#">Help</Link>
                    </li>
                    <li>
                      <span>
                        <i className="fa fa-sign-out"></i>
                      </span>
                      <Link to="#">Sign Up</Link>
                    </li>
                    <li>
                      <span>
                        <i className="fa fa-sign-in"></i>
                      </span>
                      <Link to="#">Log In</Link>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
        {/* <!-- End of header top --> */}

        {/* <!-- header bottom --> */}
        <div className="header-bottom">
          <div className="main-header">
            <div className="mobile-menu">
              <h6
                onClick={() => {
                  setOffcanvasOpen(!offcanvasOpen);
                }}
              >
                Menu <i className="fa fa-bars"></i>
              </h6>
            </div>
            <nav>
              <ul>
                <li className="active">
                  <Link to="#">FOR YOU</Link>
                </li>
                <li>
                  <Link to="/">HOMES</Link>
                </li>
                <li>
                  <Link to="/details">DETAILS</Link>
                </li>
                <li>
                  <Link to="/search">SEARCH</Link>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        {/* <!-- End of header bottom --> */}
        <div
          className={`offcanvas-menu-wrapper ${
            offcanvasOpen === true ? "show" : " "
          }`}
        >
          <div
            className="offcanvas-cancel"
            onClick={() => {
              setOffcanvasOpen(!offcanvasOpen);
            }}
          >
            X
          </div>
          <div className="offcanvas-menu">
            <ul>
              <li className="active">
                <Link to="/">FOR YOU</Link>
              </li>
              <li>
                <Link to="/">Homes</Link>
              </li>
              <li>
                <Link to="/search">SEARCH</Link>
              </li>
              <li>
                <Link to="/details">DETAILS</Link>
              </li>
            </ul>
          </div>
        </div>
      </header>
      {/* <!-- End of Header --> */}
    </>
  );
};
export default NavigationMenu;
