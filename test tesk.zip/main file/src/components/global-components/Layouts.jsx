import { React } from "react";
const Layouts = (props) => {
  return (
    <>
      {/* <!-- ==== Font awesome ==== --> */}
      <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"
      />
      <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css"
      />
      <title> {props.pageTitle} | Test Project</title>
      <div>{props.children}</div>
    </>
  );
};
export default Layouts;
