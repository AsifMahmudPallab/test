import React, { useState } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { Link, useHistory } from "react-router-dom";
import { sectionData } from "./../../data/section.json";
export default function Resort(props) {
  const [clnView, setClnView] = useState(false);
  const [clnValue, onChange] = useState(new Date());
  let data = sectionData.resort;
  let publicUrl = process.env.PUBLIC_URL + "/";
  const history = useHistory();
  const [selectRoom, setSelectRoom] = useState(data.roomCount[0].room);

  return (
    <div>
      {/* <!-- Resorts --> */}
      <section className="resort">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <div
                className="resort-inner"
                style={{
                  background: `url(${publicUrl + "assets/images/resort.jpg"})`,
                }}
              >
                <div className="heading-part">
                  <h2>Resorts</h2>
                  <p>
                    Treat yourself! your dream resort stay is just a few clicky
                    away.
                  </p>
                </div>
                {/* <!-- resort search --> */}
                <div className="resort-search">
                  {/* <!-- more place --> */}
                  <div className="more-place">
                    <i className="fa fa-bed"></i>
                    <select
                      className="form-select"
                      aria-label="Default select example"
                    >
                      <option value="DEFAULT">
                        More place then you could ever go
                      </option>
                      <option value="1">Castel House</option>
                      <option value="2">Nowabi House</option>
                      <option value="3">Castal House</option>
                    </select>
                  </div>
                  {/* <!-- End of more place --> */}

                  {/* <!-- check in --> */}
                  <div className="check-in-out">
                    <p
                      onClick={() => {
                        setClnView(!clnView);
                      }}
                    >
                      <i className="fa fa-calendar"></i>
                      check in - check out
                    </p>
                    <div
                      className="calander-view"
                      style={
                        clnView === false
                          ? { display: "none" }
                          : { display: "block" }
                      }
                    >
                      <Calendar
                        onChange={onChange}
                        value={clnValue}
                        style={{ display: "none" }}
                      />
                    </div>
                  </div>
                  {/* <!-- check in --> */}

                  {/* <!-- guest info --> */}
                  <div className="guest-info">
                    <i className="fa fa-user"></i>
                    <ul>
                      <li>
                        <select
                          className="form-select"
                          aria-label="Default select example"
                        >
                          <option value="1">1 Audults</option>
                          <option value="2">2 Audults</option>
                          <option value="3">3 Audults</option>
                        </select>
                      </li>
                      <li>
                        <select
                          className="form-select"
                          aria-label="Default select example"
                        >
                          <option value="0">0 Children</option>
                          <option value="1">1 Children</option>
                          <option value="2">2 Children</option>
                          <option value="3">3 Children</option>
                        </select>
                      </li>
                      <li>
                        <select
                          className="form-select"
                          aria-label="Default select example"
                          value={selectRoom}
                          onChange={(e) => setSelectRoom(e.target.value)}
                        >
                          {data.roomCount.map((item, i) => {
                            return (
                              <option key={i} value={item.room}>
                                {item.room} room
                              </option>
                            );
                          })}
                        </select>
                      </li>
                    </ul>
                  </div>
                  {/* <!-- End of guest info --> */}
                  {/* <!-- search --> */}
                  <div className="serach-room">
                    <Link
                      // onClick={() => {
                      //  return <Redirect to={`/search/${selectRoom}`} />;
                      // }}
                      className="search"
                      to={`/search/${selectRoom}`}
                    >
                      Search
                    </Link>
                  </div>
                  {/* <!-- End of search --> */}
                </div>
                {/* <!-- end of resort search --> */}
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- End of Resorts --> */}
    </div>
  );
}
