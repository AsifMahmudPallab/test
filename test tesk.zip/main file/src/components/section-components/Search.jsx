import React, { Component } from "react";
import { Link } from "react-router-dom";
import { sectionData } from "./../../data/section.json";

class Search extends Component {
  state = {
    data: [],
  };

  componentDidMount() {
    if (this.props.routeId === undefined) {
      this.setState({
        data: sectionData.allRoom,
      });
    } else {
      var filterRoom = sectionData.allRoom.filter(
        (room) => room.bedRoom === Number(this.props.routeId)
      );

      if (filterRoom.length > 1) {
        this.setState({
          data: [filterRoom[0], filterRoom[1]],
        });
      } else {
        this.setState({
          data: [filterRoom[0]],
        });
      }
    }
  }
  render() {
    console.log(this.props);
    return (
      <div>
        {/* <!-- search results --> */}
        <section className="search-results">
          <div className="container">
            <div className="row">
              {/* <!-- single search --> */}
              <div className="col-lg-12">
                {this.state.data.map((item, i) => {
                  return (
                    <div className="row single-search" key={i}>
                      <div className="col-md-5">
                        <div className="image">
                          <span className="icon">
                            <i className="fa fa-heart-o"></i>
                          </span>
                          <img
                            src={process.env.PUBLIC_URL + "/" + item.image1}
                            alt=""
                          />
                        </div>
                      </div>
                      <div className="col-md-7">
                        <div className="media-body">
                          <div className="star-rating">
                            <p>
                              <i className="fa fa-star"></i> <span>4.58</span> (
                              {item.raiting})
                            </p>
                          </div>
                          <span className="category">{item.roomType} room</span>
                          <h3>
                            <Link to={`/details/${item.id}`}>{item.title}</Link>
                          </h3>
                          <p className="meta">
                            {item.guest} guest . {item.bedRoom} bedroom . 1 bed
                            . {item.bathRoom} bathroom
                          </p>
                          <p className="meta">
                            wifi . Kitchen . Heating . Washing Maching
                          </p>

                          <div className="rent-price">
                            <div className="per-night">
                              <h6>
                                ${item.price} / <span>night</span>
                              </h6>
                              <p>${item.price} total</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {/* <div className="row single-search">
                 <div className="col-md-5">
                   <div className="image">
                     <span className="icon">
                       <i className="fa fa-heart-o"></i>
                     </span>
                    
                     <div className="swiper-container">
                       <div className="swiper-wrapper">
                         <div className="swiper-slide">
                           <img src="assets/images/search/search4.jpg" alt="" />
                         </div>
                         <div className="swiper-slide">
                           <img src="assets/images/search/search1.jpg" alt="" />
                         </div>
                         <div className="swiper-slide">
                           <img src="assets/images/search/search2.jpg" alt="" />
                         </div>
                         <div className="swiper-slide">
                           <img src="assets/images/search/search3.jpg" alt="" />
                         </div>
                         <div className="swiper-slide">
                           <img src="assets/images/search/search4.jpg" alt="" />
                         </div>
                       </div>
                      
                       <div className="swiper-pagination"></div>
                     </div>
                   </div>
                 </div>
                 <div className="col-md-7">
                   <div className="media-body">
                     <div className="star-rating">
                       <p>
                         <i className="fa fa-star"></i> <span>4.61</span> (207)
                       </p>
                     </div>
                     <span className="category">Private room</span>
                     <h3>Room 1 min walk form metro</h3>
                     <p className="meta">
                       3 guest . 1 bedroom . 1 bed . 2 bathroom
                     </p>
                     <p className="meta">
                       wifi . Kitchen . Heating . Washing Maching
                     </p>
 
                     <div className="rent-price">
                       <div className="per-night">
                         <h6>
                           $27 / <span>night</span>
                         </h6>
                         <p>$27 total</p>
                       </div>
                     </div>
                   </div>
                 </div>
               </div> */}
              </div>
              {/* <!-- End of single search --> */}
            </div>
            <div className="row">
              <div className="col-lg-12">
                <div className="serach-results-pagination">
                  <nav aria-label="Page navigation example">
                    <ul className="pagination">
                      <li className="page-item active">
                        <Link className="page-link" to="#">
                          1
                        </Link>
                      </li>
                      <li className="page-item">
                        <Link className="page-link" to="#">
                          2
                        </Link>
                      </li>
                      <li className="page-item">
                        <Link className="page-link" to="#">
                          3
                        </Link>
                      </li>
                      <li className="page-item">
                        <Link className="page-link" to="#">
                          <i className="fa fa-angle-right"></i>
                        </Link>
                      </li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* <!-- End of search results --> */}
      </div>
    );
  }
}

export default Search;
