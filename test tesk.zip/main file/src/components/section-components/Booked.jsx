import React from "react";
import { sectionData } from "./../../data/section.json";

export default function Booked() {
  let data = sectionData.booked;
  return (
    <div>
      {/* <!-- just booked --> */}
      <section className="just-booked pb-70">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              {/* <!-- Section title --> */}
              <div className="section-title mb-40">
                <h3>{data.heading}</h3>
              </div>
              {/* <!-- End of Section title --> */}
            </div>
          </div>
          <div className="row just-booked-row">
            {data.singleBooked.map((item, i) => {
              return (
                <div className="single-booked" key={i}>
                  <img src={item.image} alt="" />
                  <p>
                    <span>${item.price}</span> {item.content}
                  </p>
                  <div className="star-review">
                    <div className="star">
                      <i className="fa fa-star"></i>
                      <i className="fa fa-star"></i>
                      <i className="fa fa-star"></i>
                      <i className="fa fa-star"></i>
                      <i className="fa fa-star"></i>
                    </div>
                    <span>{item.review} reviews</span>
                  </div>
                </div>
              );
            })}
            {/* <!-- single booked --> */}
          </div>
        </div>
      </section>
      {/* <!-- End of just booked --> */}
    </div>
  );
}
