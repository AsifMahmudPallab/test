import React, { Component } from "react";
import { sectionData } from "./../../data/section.json";
export default class Details extends Component {
  state = {
    data: [],
  };

  componentDidMount() {
    // when route id is undefiend
    if (this.props.routeId === undefined) {
      this.setState({
        data: [
          {
            id: 1,
            title: "Stylish Spacious Double with views of the city",
            guest: 2,
            bedRoom: 1,
            bathRoom: 1,
            raiting: 215,
            price: 30,
            imageSearchView: ["assets/images/search/search1.jpg"],
            image1: "assets/images/search/search1.jpg",
            image2: "assets/images/details/r1d1.jpg",
            image3: "assets/images/details/r1d2.jpg",
            image4: "assets/images/details/r1d3.jpg",
            roomType: "private",
            author: "Shimmy",
            authorImage: "assets/images/author/reply.jpg",
            place: "London",
          },
        ],
      });
    } else {
      var filterRoom = sectionData.allRoom.filter(
        (room) => room.id === Number(this.props.routeId)
      );
      this.setState({
        data: [filterRoom[0]],
      });
    }
  }
  render() {
    return (
      <div>
        {/* <!-- room details --> */}
        <section className="room-details pb-70">
          {this.state.data.map((item, i) => {
            return (
              <div className="container" key={i}>
                <div className="row">
                  <div className="col-lg-12">
                    {/* <!-- details heading --> */}
                    <div className="details-heading">
                      <h3>
                        Hotel Alborada Ocean Club
                        <i className="fa fa-star"></i>
                        <i className="fa fa-star"></i>
                        <i className="fa fa-star"></i>
                      </h3>
                      <p>Casta del Silencio , Tenerife, Canary island</p>
                      <div className="review-star">
                        <i className="fa fa-star"></i>
                        <i className="fa fa-star"></i>
                        <i className="fa fa-star"></i>
                        <i className="fa fa-star"></i>
                        <i className="fa fa-star-o"></i>
                        <span>325 review</span>
                      </div>
                    </div>
                    {/* <!-- End of details heading --> */}
                  </div>
                </div>
                <div className="row no-gutter">
                  <div className="col-md-8">
                    <div className="room-image">
                      <img
                        src={`${process.env.PUBLIC_URL}/${item.image2}`}
                        alt=""
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="room-image">
                      <img
                        src={`${process.env.PUBLIC_URL}/${item.image3}`}
                        alt=""
                      />
                    </div>
                    <div className="room-image">
                      <img
                        src={`${process.env.PUBLIC_URL}/${item.image4}`}
                        alt=""
                      />
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-lg-8">
                    {/* <!-- details content --> */}
                    <div className="details-content">
                      <div className="author">
                        <img
                          src={`${process.env.PUBLIC_URL}/${item.authorImage}`}
                          alt=""
                        />
                        <span>{item.author}</span>
                      </div>
                      <h3 className="title">{item.title}</h3>
                      <span className="category">Greater {item.place}</span>

                      <div className="special-info">
                        <ul>
                          <li>
                            <i className="fa fa-home"></i>
                            <h5>Privet Room in flat</h5>
                            <p>2 guests 1bedroom 1bed 1share bathroom</p>
                          </li>
                          <li>
                            <i className="fa fa-check-square-o"></i>
                            <h5>Self Check-in</h5>
                            <p>Check your self in with the lockbox</p>
                          </li>
                          <li>
                            <i className="fa fa-coffee"></i>
                            <h5>Breakfast</h5>
                            <p>
                              This is one of the few place in the area that has
                              this feature.
                            </p>
                          </li>
                          <li>
                            <i className="fa fa-phone"></i>
                            <h5>Great communication</h5>
                            <p>
                              100% of recent geusts reted Shimmy 5-star is
                              communication
                            </p>
                          </li>
                        </ul>
                      </div>

                      <div className="extra-info">
                        <p>
                          A spacioua double room with a comfy king size bed in
                          the heart of the East end
                        </p>

                        <ul>
                          <li>
                            <p>-5min walk from underground</p>
                          </li>
                          <li>
                            <p>-5min walk to shadowell DL station</p>
                          </li>
                          <li>
                            <p>-10 min by train to city</p>
                          </li>
                          <li>
                            <p>-5min by train to trendy shoping complex</p>
                          </li>
                          <li>
                            <p>Easy access to all tourist destination</p>
                          </li>
                        </ul>
                      </div>
                    </div>
                    {/* <!-- details content --> */}
                  </div>
                  <div className="col-lg-4">
                    <aside>
                      <div className="single-sidebar">
                        <div className="sitebar-top">
                          <h3>
                            ${item.price} <span>per night</span>
                          </h3>
                          <p>
                            <i className="fa fa-star"></i>4.58 ({item.raiting}{" "}
                            review)
                          </p>
                        </div>
                        <div className="date">
                          <h6>Dates</h6>
                          <div className="date-box">
                            <span>20/02/2020</span>
                            <i className="fa fa-long-arrow-right"></i>
                            <span>21/02/2020</span>
                          </div>
                        </div>
                        <div className="guest">
                          <h6>Guest</h6>
                          <select
                            className="form-select"
                            aria-label="Default select example"
                          >
                            <option value="1">1 Guest</option>
                            <option value="2">2 Guest</option>
                            <option value="3">3 Guest</option>
                            <option value="4">4 Guest</option>
                          </select>
                        </div>
                        <div className="bill">
                          <table className="responsive-table">
                            <tbody>
                              <tr>
                                <td>${item.price} * 1 night</td>
                                <td>${item.price}</td>
                              </tr>
                              <tr>
                                <td>Cleaning fee</td>
                                <td>$5</td>
                              </tr>
                              <tr>
                                <td>Service fee</td>
                                <td>$4</td>
                              </tr>
                              <tr>
                                <td className="total">Total</td>
                                <td>${item.price + 9}</td>
                              </tr>
                            </tbody>
                          </table>
                          <div className="submit-bill">
                            <button>Reserve</button>
                          </div>
                          <div className="warning">
                            <p>
                              You won't be changed yet <br /> Certain
                              revservtion may also require a security deposit
                            </p>
                          </div>
                        </div>
                      </div>
                    </aside>
                  </div>
                </div>
              </div>
            );
          })}
        </section>
        {/* // <!-- End of room details --> */}
      </div>
    );
  }
}
