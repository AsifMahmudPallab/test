import React from "react";
import { Link } from "react-router-dom";
import { sectionData } from "./../../data/section.json";

export default function EyePlace() {
  let data = sectionData.eyePlace;
  return (
    <div>
      {/* <!-- eye place --> */}
      <section className="eye-place pb-70">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              {/* <!-- Section title --> */}
              <div className="section-title mb-40">
                <h3>{data.heading}</h3>
                <div className="see-more">
                  <Link to="#">
                    See More <i className="fa fa-angle-right"></i>
                  </Link>
                </div>
              </div>
              {/* <!-- End of Section title --> */}
            </div>
          </div>
          <div className="row just-booked-row">
            {/* <!-- single eye place --> */}
            {data.singlePlace.map((item, i) => {
              return (
                <div className="single-eye-place" key={i}>
                  <div className="image">
                    <img src={item.image} alt="" />
                    <div className="figure-caption">
                      <span className="category">Guide</span>
                      <h6 className="title">{item.title}</h6>
                    </div>
                  </div>
                  <p>
                    by {item.author} {item.category}
                  </p>
                </div>
              );
            })}
            {/* <!-- End of single eye place --> */}
          </div>
        </div>
      </section>
      {/* <!-- End of eye place --> */}
    </div>
  );
}
