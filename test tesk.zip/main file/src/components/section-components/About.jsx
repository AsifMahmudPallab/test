import React from "react";
import { sectionData } from "./../../data/section.json";

const AboutRaiting = () => {
  let data = sectionData.about;
  return (
    <div>
      {/* <!-- About Home --> */}
      <section className="about-home pb-70">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              {/* <!-- Section title --> */}
              <div className="section-title">
                <h3>
                  What guests are saying about homes in the United kingdom
                </h3>
                <p>
                  United kindom homes were rated
                  <b>{data.heading.star} out of 5 Stars</b>with
                  <b>10,500,000+</b>reviews
                </p>
              </div>
              {/* <!-- End of Section title --> */}
            </div>
          </div>
          <div className="row justify-content-center">
            {data.singleAbout.map((item, i) => {
              return (
                <div className="col-lg-4 col-md-6" key={i}>
                  {/* <!-- single about --> */}
                  <div className="single-about">
                    <img src={item.image} alt="" />
                    <div className="stars">
                      <i className="fa fa-star"></i>
                      <i className="fa fa-star"></i>
                      <i className="fa fa-star"></i>
                      <i className="fa fa-star"></i>
                      <i className="fa fa-star"></i>
                    </div>
                    <p>{item.comment}</p>

                    <div className="author media">
                      <img src={item.authorImage} alt="" />
                      <div className="media-body">
                        <h6>{item.authorName}</h6>
                        <p>{item.acuthorCountry}</p>
                      </div>
                    </div>
                  </div>
                  {/* <!-- End of single about --> */}
                </div>
              );
            })}
          </div>
        </div>
      </section>
      {/* <!-- End of About Home --> */}
    </div>
  );
};

export default AboutRaiting;
