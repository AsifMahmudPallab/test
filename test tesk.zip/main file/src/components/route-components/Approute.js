import React from 'react';
import { BrowserRouter, Route, Switch } from "react-router-dom";
import DetailsPage from '../../page/DetailsPage.jsx';
import Home from '../../page/Home';
import SearchPage from '../../page/SearchPage.jsx';

function AppRoute() {

    return (
        < BrowserRouter >
            < Switch >
                < Route path = '/' exact component = { Home } />  
                < Route path = {`${process.env.PUBLIC_URL}/details/:id`} exact component = { DetailsPage } />  
                < Route path = '/details' exact component = { DetailsPage } />  
                < Route path = {`${process.env.PUBLIC_URL}/search/:id`} exact component = { SearchPage } />
                < Route path = '/search' exact component = { SearchPage } />
            </ Switch> 
        </ BrowserRouter>
    )
        
    
}
export default AppRoute;