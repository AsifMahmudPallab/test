import React, { Component } from "react";
import Footer from "../components/global-components/Footer";
import Layouts from "../components/global-components/Layouts";
import NavigationMenu from "../components/global-components/NavigationMenu";
import Resort from "../components/section-components/Resort";
import Search from "../components/section-components/Search";

class SearchPage extends Component {
  render() {
    return (
      <Layouts pageTitle="Search">
        <NavigationMenu />
        <Resort />
        <Search routeId={this.props.match.params.id} />
        <Footer />
      </Layouts>
    );
  }
}
export default SearchPage;
