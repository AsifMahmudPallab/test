import React, { Component } from "react";
import Footer from "../components/global-components/Footer";
import AboutRaiting from "../components/section-components/About";
import Booked from "../components/section-components/Booked";
import EyePlace from "../components/section-components/EyePlace";
import Resort from "../components/section-components/Resort";
import Layouts from "./../components/global-components/Layouts";
import NavigationMenu from "./../components/global-components/NavigationMenu";
class Home extends Component {
  state = {
    isOpen: false,
  };
  setOpen = () => {
    this.setState({
      isOpen: !this.state.isOpen,
    });
  };
  componentDidMount() {
    window.scrollTo(0, 0);
  }
  render() {
    return (
      <Layouts pageTitle="Home">
        <NavigationMenu />
        <Resort />
        <AboutRaiting />
        <Booked />
        <EyePlace />
        <Footer />
      </Layouts>
    );
  }
}
export default Home;
