import { React } from 'react';
import '../assets/css/responsive.css';
import AppRoute from '../components/route-components/Approute';
function App() {
  return (
   <AppRoute />
  );
}

export default App;
