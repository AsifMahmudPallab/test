import React, { Component } from "react";
import Footer from "../components/global-components/Footer";
import Layouts from "../components/global-components/Layouts";
import NavigationMenu from "../components/global-components/NavigationMenu";
import Resort from "../components/section-components/Resort";
import Details from "./../components/section-components/Details";

class DetailsPage extends Component {
  render() {
    return (
      <Layouts pageTitle="Details">
        <NavigationMenu />
        <Resort />
        <Details routeId={this.props.match.params.id} />
        <Footer />
      </Layouts>
    );
  }
}
export default DetailsPage;
